#!/usr/bin/env python3
"""
Buyer Data Import Script for Splash25 Migration

This script:
1. Reads buyer data from Excel file
2. Creates user accounts with secure passwords
3. Populates buyer-related tables in the database
4. Exports user credentials to a separate Excel file

Usage:
    python import_buyers.py [options]

Options:
    -i, --input-file     Input Excel file path (default: Buyers_20250623.xlsx)
    -d, --db-name        Database name (default: splash25_core_db)
    -h, --db-host        Database host (default: localhost)
    -p, --db-port        Database port (default: 5432)
    -u, --db-user        Database user (default: splash25user)
    -pw, --db-password   Database password (default: splash25password)
    -o, --output-file    Output credentials file (default: buyer_credentials_YYYYMMDD_HHMMSS.xlsx)
"""

import os
import sys
import logging
import random
import string
import subprocess
import argparse
import pandas as pd
import bcrypt
import json
from datetime import datetime
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill
from nc_py_api import Nextcloud, NextcloudException
from io import BytesIO
from PIL import Image
import base64
import requests
from urllib.parse import urlparse
from werkzeug.utils import secure_filename
import dotenv
import time

# Check for required libraries
try:
    import psycopg2
    from psycopg2 import sql
except ImportError:
    print("Error: Required Python libraries not found.")
    print("Please install required packages using: pip install -r requirements.txt")
    sys.exit(1)

# Default configuration variables
DEFAULT_DB_USER = "splash25user"
DEFAULT_DB_PASSWORD = "splash25password"
DEFAULT_DB_HOST = "localhost"
DEFAULT_DB_PORT = "5432"
DEFAULT_DB_NAME = "splash25_migration_test_db"
DEFAULT_EXCEL_FILE = "Buyers_20250623.xlsx"
# Generate credentials filename with current date and time
DEFAULT_CREDENTIALS_FILE = f"buyer_credentials_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"

# These will be set by parse_arguments() or use defaults
DB_USER = DEFAULT_DB_USER
DB_PASSWORD = DEFAULT_DB_PASSWORD
DB_HOST = DEFAULT_DB_HOST
DB_PORT = DEFAULT_DB_PORT
DB_NAME = DEFAULT_DB_NAME
EXCEL_FILE = DEFAULT_EXCEL_FILE
CREDENTIALS_FILE = DEFAULT_CREDENTIALS_FILE

# Set up logging
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
# Generate log filename with current date and time
LOG_FILE = os.path.join(SCRIPT_DIR, f"buyer_import_log_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log")

# Load environment variables from .env file
dotenv.load_dotenv(os.path.join(SCRIPT_DIR, '.env'))
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(LOG_FILE),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Column mappings section
COLUMN_MAPPINGS = {
    "users": {
        "username": "buyer id",  # Use buyer id as username
        "email": "Email",
        "password_hash": None,  # Will be generated
        "role": None,  # Will be set to 'buyer'
        "business_name": "Company",
        "business_description": None  # Not available in Excel
    },
    "buyer_profiles": {
        "user_id": None,  # Will be set from the created user
        "name": "Name",  # Will be parsed into first_name and last_name
        "first_name": None,  # Will be set from parsed Name
        "last_name": None,  # Will be set from parsed Name
        "designation": "Designation",
        "organization": "Company",
        "mobile": "Mobile",
        "address": "Address",
        "city": "City",
        "state": "State",
        "pincode": "Pincode",
        "website": "Website",
        "instagram": "Instagram",
        "gst": "GSTIN",
        "operator_type": "Operator Type",
        "country": None,  # Will be set to 'India'
        "interests": "Interests",  # Will be converted to JSONB
        "properties_of_interest": "Interest Segment",  # Will be converted to JSONB
        "year_of_starting_business": "Started On",
        "selling_wayanad": None,  # Will be set to False
        "vip": None,  # Will be set to False
        "category_id": None,  # Will be set based on buyer_categories where name is "Hosted"
        "since_when": "Promoting Since"
    },
    "buyer_misc": {
        "buyer_id": None,  # Will be set from the created profile
        "previous_visit": "Previous opinion",  # Will be processed with logic: If "I haven't attended before" or blank, set to False, else True
        "previous_stay_property": "Previous stayed property",
        "why_visit": "Reason for Splash Visit"
    },
    "buyer_references": {
        "buyer_profile_id": None,  # Will be set from the created profile
        "ref1_name": "Promoting Property 1",
        "ref1_address": "Promoting Property Address 1",
        "ref2_name": "Promoting Property 2",
        "ref2_address": "Promoting Property Address 2",
    },
    "buyer_financial_info": {
        "buyer_profile_id": None,  # Will be set from the created profile
        "payment_date": "UTR Date",
        "payment_reference": "UTR Number",  # Add mapping for payment_reference
        "deposit_paid": None,  # Will be set to True
        "entry_fee_paid": None,  # Will be set to True
        "deposit_amount": None,  # Will be set to 0
        "entry_fee_amount": None  # Will be set to 0
    },
    "buyer_business_info": {
        "buyer_profile_id": None,  # Will be set from the created profile
        "start_year": "Started On",  # Changed from started_on to start_year
        "sell_wayanad": "Promoting Wayanad",  # Using correct field name sell_wayanad
        "sell_wayanad_year": "Promoting Since" , # Using correct field name sell_wayanad_year
        "property_interest_1": "Promoting Property Address 1",
        "property_interest_2": "Promoting Property Address 2",
        "previous_visit": "Previous opinion",  # Will be processed with logic: If "I haven't attended before" or blank, set to False, else True
        "previous_stay_property": "Previous stayed property",
        "why_visit": "Reason for Splash Visit"
    }
}

def parse_arguments():
    """Parse command line arguments"""
    parser = argparse.ArgumentParser(description="Import buyer data from Excel to database")
    
    # Add arguments
    parser.add_argument("-i", "--input-file", 
                        help=f"Input Excel file path (default: {DEFAULT_EXCEL_FILE})",
                        default=DEFAULT_EXCEL_FILE)
    
    parser.add_argument("-d", "--db-name", 
                        help=f"Database name (default: {DEFAULT_DB_NAME})",
                        default=DEFAULT_DB_NAME)
    
    parser.add_argument("-H", "--db-host", 
                        help=f"Database host (default: {DEFAULT_DB_HOST})",
                        default=DEFAULT_DB_HOST)
    
    parser.add_argument("-p", "--db-port", 
                        help=f"Database port (default: {DEFAULT_DB_PORT})",
                        default=DEFAULT_DB_PORT)
    
    parser.add_argument("-u", "--db-user", 
                        help=f"Database user (default: {DEFAULT_DB_USER})",
                        default=DEFAULT_DB_USER)
    
    parser.add_argument("-pw", "--db-password", 
                        help=f"Database password (default: {DEFAULT_DB_PASSWORD})",
                        default=DEFAULT_DB_PASSWORD)
    
    parser.add_argument("-o", "--output-file", 
                        help=f"Output credentials file (default: {DEFAULT_CREDENTIALS_FILE})",
                        default=DEFAULT_CREDENTIALS_FILE)
    
    return parser.parse_args()

def check_setup_script_executed():
    """Ask user to confirm setup script has been executed"""
    response = input("Have you already executed setup_migration_db.py? (Yes/No): ")
    if response.lower() != "yes":
        logger.info("Running setup_migration_db.py first...")
        try:
            setup_script = os.path.join(SCRIPT_DIR, "setup_migration_db.py")
            # Pass database connection parameters to setup script
            subprocess.run([
                "python3", 
                setup_script,
                "-d", DB_NAME,
                "-H", DB_HOST,
                "-p", DB_PORT,
                "-u", DB_USER,
                "-pw", DB_PASSWORD
            ], check=True)
            logger.info("Setup script completed successfully.")
        except subprocess.CalledProcessError as e:
            logger.error(f"Failed to run setup script: {e}")
            sys.exit(1)
    else:
        logger.info("Proceeding with buyer data import...")

def generate_password():
    """Generate a secure random password between 8-10 characters"""
    # Define character sets
    lowercase = string.ascii_lowercase
    uppercase = string.ascii_uppercase
    digits = string.digits
    special = "!@#$%^&*()-_=+[]{}|;:,.<>?"
    
    # Randomly choose a length between 8 and 10
    length = random.randint(8, 10)
    
    # Ensure at least one character from each set
    password = [
        random.choice(lowercase),
        random.choice(uppercase),
        random.choice(digits),
        random.choice(special)
    ]
    
    # Fill the rest of the password
    remaining_length = length - len(password)
    all_chars = lowercase + uppercase + digits + special
    password.extend(random.choice(all_chars) for _ in range(remaining_length))
    
    # Shuffle the password characters
    random.shuffle(password)
    
    return ''.join(password)

def hash_password(password):
    """Create a bcrypt hash of the password using BF salt"""
    # Generate a salt and hash the password
    salt = bcrypt.gensalt()  # Uses BF by default
    hashed = bcrypt.hashpw(password.encode('utf-8'), salt)
    return hashed.decode('utf-8')

def parse_name(full_name):
    """Parse full name into first name and last name with proper capitalization"""
    if not full_name or pd.isna(full_name):
        return "", ""
    
    # Split the name by spaces
    name_parts = full_name.strip().split()
    
    if len(name_parts) == 0:
        return "", ""
    elif len(name_parts) == 1:
        # Only one name provided, treat as first name
        return name_parts[0].capitalize(), ""
    else:
        # First part is first name, rest is last name
        first_name = name_parts[0].capitalize()
        last_name = " ".join(part.capitalize() for part in name_parts[1:])
        return first_name, last_name

def convert_to_jsonb(value):
    """Convert a string value to JSONB format"""
    if not value or pd.isna(value):
        return json.dumps([])
    
    # Split by commas and clean up each item
    items = [item.strip() for item in str(value).split(',') if item.strip()]
    
    # Return as a JSON array string
    return json.dumps(items)

def get_hosted_category_id(cursor):
    """Get the category ID for 'Hosted' from buyer_categories table"""
    try:
        cursor.execute("SELECT id FROM buyer_categories WHERE name = 'Hosted'")
        result = cursor.fetchone()
        if result:
            return result[0]
        else:
            logger.warning("Category 'Hosted' not found in buyer_categories table, using default value 1")
            return 1
    except Exception as e:
        logger.error(f"Error getting Hosted category ID: {e}")
        return 1

def read_excel_data(file_path):
    """Read data from Excel file"""
    try:
        excel_path = os.path.join(SCRIPT_DIR, file_path)
        df = pd.read_excel(excel_path)
        logger.info(f"Successfully read {len(df)} records from {file_path}")
        return df
    except Exception as e:
        logger.error(f"Error reading Excel file: {e}")
        sys.exit(1)

def get_table_columns(cursor, table_name):
    """Get column names for a database table"""
    try:
        cursor.execute(f"SELECT column_name FROM information_schema.columns WHERE table_name = '{table_name}' ORDER BY ordinal_position")
        columns = [row[0] for row in cursor.fetchall()]
        return columns
    except Exception as e:
        logger.error(f"Error getting columns for table {table_name}: {e}")
        return []

def insert_user_data(cursor, user_data):
    """Insert data into users table"""
    try:
        # Generate a password and hash it
        clear_password = generate_password()
        password_hash = hash_password(clear_password)
        
        # Prepare the SQL query
        columns = ["username", "email", "password_hash", "role", "business_name"]
        values = [
            user_data.get("username"),
            user_data.get("email"),
            password_hash,
            "buyer",
            user_data.get("business_name")
        ]
        
        placeholders = ", ".join(["%s"] * len(values))
        column_str = ", ".join(columns)
        
        query = f"INSERT INTO users ({column_str}) VALUES ({placeholders}) RETURNING id"
        
        try:
            cursor.execute(query, values)
            user_id = cursor.fetchone()[0]
        
            logger.info(f"Created user with ID {user_id} for {user_data.get('email')}")
        
            # Return user ID and clear text password
            return user_id, clear_password
        except Exception as e:
            logger.error("SQL execution failed: %s | Params: %s | Error: %s", query, values, str(e))
            raise e
    except Exception as e:
        logger.error(f"Error inserting user data: {e}")
        return None, None

def insert_buyer_profile_data(cursor, profile_data, user_id):
    """Insert data into buyer_profiles table"""
    try:
        # Add user_id to profile data
        profile_data["user_id"] = user_id
        
        # Set default values for missing fields
        profile_data["status"] = "active"
        profile_data["country"] = "India"
        profile_data["selling_wayanad"] = False
        profile_data["vip"] = False
        
        # Get the category_id for "Hosted"
        profile_data["category_id"] = get_hosted_category_id(cursor)
        
        # Parse name into first_name and last_name
        if "name" in profile_data:
            first_name, last_name = parse_name(profile_data["name"])
            profile_data["first_name"] = first_name
            profile_data["last_name"] = last_name
        
        # Convert interests and properties_of_interest to JSONB
        if "interests" in profile_data and profile_data["interests"] is not None:
            profile_data["interests"] = convert_to_jsonb(profile_data["interests"])
        
        if "properties_of_interest" in profile_data and profile_data["properties_of_interest"] is not None:
            profile_data["properties_of_interest"] = convert_to_jsonb(profile_data["properties_of_interest"])
        
        # Convert pincode to integer
        if "pincode" in profile_data and profile_data["pincode"] is not None:
            try:
                if not pd.isna(profile_data["pincode"]):
                    profile_data["pincode"] = int(float(profile_data["pincode"]))
                else:
                    profile_data["pincode"] = None
            except (ValueError, TypeError):
                logger.warning(f"Invalid pincode: {profile_data['pincode']}, setting to None")
                profile_data["pincode"] = None
        
        # Convert year_of_starting_business to integer
        if "year_of_starting_business" in profile_data:
            try:
                if not pd.isna(profile_data["year_of_starting_business"]):
                    profile_data["year_of_starting_business"] = int(float(profile_data["year_of_starting_business"]))
                else:
                    profile_data["year_of_starting_business"] = None
            except (ValueError, TypeError):
                logger.warning(f"Invalid year_of_starting_business: {profile_data['year_of_starting_business']}, setting to None")
                profile_data["year_of_starting_business"] = None
        
        # Set default value for since_when
        if "since_when" in profile_data:
            if pd.isna(profile_data["since_when"]) or not profile_data["since_when"]:
                profile_data["since_when"] = 1900
            else:
                try:
                    profile_data["since_when"] = int(float(profile_data["since_when"]))
                except (ValueError, TypeError):
                    logger.warning(f"Invalid since_when: {profile_data['since_when']}, setting to 1900")
                    profile_data["since_when"] = 1900

        # Prepare the SQL query
        columns = []
        values = []
        
        for key, value in profile_data.items():
            if value is not None and key in get_table_columns(cursor, "buyer_profiles"):
                columns.append(key)
                values.append(value)
        
        placeholders = ", ".join(["%s"] * len(values))
        column_str = ", ".join(columns)
        
        query = f"INSERT INTO buyer_profiles ({column_str}) VALUES ({placeholders}) RETURNING id"
        
        try:
            cursor.execute(query, values)
            profile_id = cursor.fetchone()[0]
        
            logger.info(f"Created buyer profile with ID {profile_id} for user {user_id}")
        
            return profile_id
        except Exception as e:
            logger.error("SQL execution failed: %s | Params: %s | Error: %s", query, values, str(e))
            raise e
    except Exception as e:
        logger.error(f"Error inserting buyer profile data: {e}")
        return None

def insert_buyer_misc(cursor, misc_data, profile_id):
    """Insert data into buyer_misc table"""
    try:
        # Add profile_id to misc data as buyer_id
        misc_data["buyer_id"] = profile_id
        
        # Process previous_visit based on "Previous opinion" field
        if "previous_visit" in misc_data:
            previous_opinion = misc_data["previous_visit"]
            if pd.isna(previous_opinion) or previous_opinion == "I haven't attended before":
                misc_data["previous_visit"] = False
            else:
                misc_data["previous_visit"] = True
        
        # Set default value for previous_stay_property
        if "previous_stay_property" in misc_data and pd.isna(misc_data["previous_stay_property"]):
            misc_data["previous_stay_property"] = ""
        
        # Set default value for why_visit
        if "why_visit" in misc_data and pd.isna(misc_data["why_visit"]):
            misc_data["why_visit"] = ""
        
        # Prepare the SQL query
        columns = []
        values = []
        
        for key, value in misc_data.items():
            if value is not None and key in get_table_columns(cursor, "buyer_misc"):
                columns.append(key)
                values.append(value)
        
        placeholders = ", ".join(["%s"] * len(values))
        column_str = ", ".join(columns)
        
        query = f"INSERT INTO buyer_misc ({column_str}) VALUES ({placeholders})"
        
        try:
            cursor.execute(query, values)
            
            logger.info(f"Created buyer misc data for profile {profile_id}")
        
            return True
        except Exception as e:
            logger.error("SQL execution failed: %s | Params: %s | Error: %s", query, values, str(e))
            raise e
    except Exception as e:
        logger.error(f"Error inserting buyer misc data: {e}")
        return None

def insert_buyer_references(cursor, reference_data, profile_id):
    """Insert data into buyer_references table"""
    try:
        # Add profile_id to reference data
        reference_data["buyer_profile_id"] = profile_id
        
        # Set default values for missing fields
        if "ref1_name" in reference_data and pd.isna(reference_data["ref1_name"]):
            reference_data["ref1_name"] = ""
        if "ref1_address" in reference_data and pd.isna(reference_data["ref1_address"]):
            reference_data["ref1_address"] = ""
        if "ref2_name" in reference_data and pd.isna(reference_data["ref2_name"]):
            reference_data["ref2_name"] = ""
        if "ref2_address" in reference_data and pd.isna(reference_data["ref2_address"]):
            reference_data["ref2_address"] = ""
        if "property_interest_1" in reference_data and pd.isna(reference_data["property_interest_1"]):
            reference_data["property_interest_1"] = ""
        if "property_interest_2" in reference_data and pd.isna(reference_data["property_interest_2"]):
            reference_data["property_interest_2"] = ""
        
        # Prepare the SQL query
        columns = []
        values = []
        
        for key, value in reference_data.items():
            if value is not None and key in get_table_columns(cursor, "buyer_references"):
                columns.append(key)
                values.append(value)
        
        placeholders = ", ".join(["%s"] * len(values))
        column_str = ", ".join(columns)
        
        query = f"INSERT INTO buyer_references ({column_str}) VALUES ({placeholders}) RETURNING id"
        
        try:
            cursor.execute(query, values)
            reference_id = cursor.fetchone()[0]
        
            logger.info(f"Created buyer references with ID {reference_id} for profile {profile_id}")
        
            return reference_id
        except Exception as e:
            logger.error("SQL execution failed: %s | Params: %s | Error: %s", query, values, str(e))
            raise e
    except Exception as e:
        logger.error(f"Error inserting buyer references: {e}")
        return None

def upload_buyer_profile_image(unique_id, buyer_profile_id, cursor):
    """
    Download image from NextCloud and update buyer profile
    
    Args:
        unique_id: The unique ID from the Excel file
        buyer_profile_id: The ID of the buyer profile to update
        cursor: Database cursor for executing SQL queries
    
    Returns:
        str: Public URL of the uploaded image or None if failed
    """
    try:
        # Load environment variables
        storage_base_url = os.getenv('EXTERNAL_STORAGE_URL')
        if not storage_base_url:
            logger.warning("EXTERNAL_STORAGE_URL not set, skipping image upload")
            return None
            
        storage_url = storage_base_url + "index.php"
        storage_user = os.getenv('EXTERNAL_STORAGE_USER')
        storage_password = os.getenv('EXTERNAL_STORAGE_PASSWORD')
        ocs_url = storage_base_url + 'ocs/v2.php/apps/files_sharing/api/v1/shares'
        
        # Check if all required environment variables are set
        if not all([storage_user, storage_password]):
            logger.warning("External storage credentials missing, skipping image upload")
            return None
        
        # Initialize NextCloud client
        nc = Nextcloud(nextcloud_url=storage_url, nc_auth_user=storage_user, nc_auth_pass=storage_password)
        
        # Set up headers and auth for OCS API
        ocs_headers = {'OCS-APIRequest': 'true', "Accept": "application/json"}
        # Ensure storage_user and storage_password are not None for auth tuple
        ocs_auth = (str(storage_user), str(storage_password))
        file_public_url=""
        source_image_available = False
        # Path to the source image in NextCloud
        source_image_path = f"/Photos/buyer/{unique_id}.jpg"
        #source_utr_image_path = f"/Photos/buyer/{unique_id}_UTR.jpg"
        
        # Try to download the image
        try:
            # Download the image to a BytesIO object
            #image_data = nc.files.download_stream(source_image_path)
            # Prepare an in-memory buffer (or any file-like object)
            buffer = BytesIO()
            #utr_buffer = BytesIO()
            # Use the internal session to download in chunks
            try:
                nc._session.download2stream(
                    f"/files/{storage_user}{source_image_path}",
                    buffer,
                    dav=True
                )
                # Read the buffer from the start
                buffer.seek(0)
                image_data = buffer.read()
                if not image_data:
                    logger.warning(f"Image not found at {source_image_path}")
                    file_public_url = ""
                    source_image_available = False
                else:
                    source_image_available = True
                    #return None
            except Exception as e:
                logger.error(f"Error while reading source file::::{str(e)}")
                file_public_url =""
                source_image_available = False

            #utr_image_data = nc.files.download_stream(source_utr_image_path)
            """
            nc._session.download2stream(
                f"/files/{storage_user}{source_utr_image_path}",
                utr_buffer,
                dav=True
            )
            # Read the buffer from the start
            utr_buffer.seek(0)
            utr_image_data = utr_buffer.read()
            if not utr_image_data:
                logger.warning(f"UTR Payment Info not found for unique id {unique_id}")
            """    
            # Create directory structure for buyer images if it doesn't exist
            if source_image_available:
                buyer_dir = f"buyer_{buyer_profile_id}"
                remote_dir_path = f"/Photos/migration_test/{buyer_dir}"
                remote_profile_images_path = f"{remote_dir_path}/profile"
                #remote_utr_images_path = f"/Photos/{buyer_dir}/payment"

                # Check if buyer directory exists, create if not
                try:
                    nc.files.listdir(remote_dir_path)
                    logger.debug(f"Found remote path: {remote_dir_path}")
                except NextcloudException as e:
                    if e.status_code == 404:
                        # Create directory and set sharing permissions
                        nc.files.mkdir(remote_dir_path)
                        logger.debug(f"Created remote directory {remote_dir_path}")
                        dir_sharing_data = {
                            'path': remote_dir_path,
                            'shareType': 3,  # Public link
                            'permissions': 1  # Read-only
                        }
                        response = requests.post(ocs_url, headers=ocs_headers, data=dir_sharing_data, auth=ocs_auth)
                        if response.status_code != 200:
                            logger.warning(f"Failed to set sharing permissions for {remote_dir_path}")
                    else:
                        logger.error(f"An unknown error occured while trying to list directory contents: {remote_dir_path}: {str(e)}")
                        file_public_url=""
                        #raise e
                # Check if profile images directory exists, create if not
                try:
                    nc.files.listdir(remote_profile_images_path)
                    logger.debug(f"Found remote path: {remote_profile_images_path}")
                except NextcloudException as e:
                    if e.status_code == 404:
                        # Create directory and set sharing permissions
                        nc.files.mkdir(remote_profile_images_path)
                        logger.debug(f"Created remote directory {remote_profile_images_path}")
                        dir_sharing_data = {
                            'path': remote_profile_images_path,
                            'shareType': 3,  # Public link
                            'permissions': 1  # Read-only
                        }
                        response = requests.post(ocs_url, headers=ocs_headers, data=dir_sharing_data, auth=ocs_auth)
                        if response.status_code != 200:
                            logger.warning(f"Failed to set sharing permissions for {remote_profile_images_path}")
                    else:
                        logger.error(f"An unknown error occured while trying to list directory contents: {remote_profile_images_path}: {str(e)}")
                        file_public_url = ""
                        #raise e
                # Check if UTR images directory exists, create if not
                """
                try:
                    nc.files.listdir(remote_utr_images_path)
                    logger.debug(f"Found remote path: {remote_utr_images_path}")
                except NextcloudException as e:
                    if e.status_code == 404:
                        # Create directory and set sharing permissions
                        nc.files.mkdir(remote_utr_images_path)
                        logger.debug(f"Created remote directory {remote_utr_images_path}")
                        No need to make UTR dir public
                        dir_sharing_data = {
                            'path': remote_utr_images_path,
                            'shareType': 3,  # Public link
                            'permissions': 1  # Read-only
                        }
                        response = requests.post(ocs_url, headers=ocs_headers, data=dir_sharing_data, auth=ocs_auth)
                        
                        if response.status_code != 200:
                            logger.warning(f"Failed to set sharing permissions for {remote_utr_images_path}")
                    else:
                        logger.error(f"An unknown error occured while trying to list directory contents: {remote_utr_images_path}: {str(e)}")
                        raise e
                #utr_filename = secure_filename(f"buyer_{buyer_profile_id}_UTR.jpg")
                #utr_upload_url = f"remote_utr_images_path/{utr_filename}"
                """
        
                # Generate unique filename for the uploaded image
                filename = secure_filename(f"buyer_{buyer_profile_id}.jpg")
                upload_url = f"{remote_profile_images_path}/{filename}"
                # Upload the image
                buf = BytesIO(image_data)
                buf.seek(0)
                uploaded_file = nc.files.upload_stream(upload_url, buf)
                logger.info(f"Uploaded file: {uploaded_file.name}")
            
                # Create public share for the uploaded image
                file_sharing_data = {
                    'path': upload_url,
                    'shareType': 3,  # Public link
                    'permissions': 1  # Read-only
                }
                #response = requests.post(ocs_url, headers=ocs_headers, data=file_sharing_data, auth=ocs_auth)
                max_retries = 3
                for attempt in range(max_retries):
                    response = requests.post(ocs_url, headers=ocs_headers, data=file_sharing_data, auth=ocs_auth)
                    if response.status_code == 200:
                        break
                    elif response.status_code == 429:
                        wait = 2 ** attempt
                        logger.warning(f"Rate limited. Retrying in {wait} seconds...")
                        time.sleep(wait)
                    else:
                        logger.warning(f"Unexpected status {response.status_code}: {response.text}")
                        break
                if response.status_code != 200:
                    logger.warning(f"Failed to create public share for {upload_url}")
                    file_public_url=""
                    #return None
            
                # Extract public URL from response
                result = response.json()
                if result["ocs"]["meta"]["status"] != "ok":
                    logger.warning(f"Share API error: {result['ocs']['meta']['message']}")
                    file_public_url=""
                    #return None
            
                file_public_url = result["ocs"]["data"]["url"]
                logger.debug(f"Public share URL: {file_public_url}")
            
                # Update buyer profile with the image URL
                update_query = "UPDATE buyer_profiles SET profile_image = %s WHERE id = %s"
                try:
                    cursor.execute(update_query, (file_public_url, buyer_profile_id))
                except Exception as e:
                    logger.error("SQL execution failed: %s | Params: %s | Error: %s", query, values, str(e))
                    raise e
            
                # Next upload the UTR file -- No need to set permissions on this as this needs to be viewed offline only for now 
                #buf = BytesIO(utr_image_data)
                #buf.seek(0)
                #uploaded_file = nc.files.upload_stream(utr_upload_url, buf)
                #logger.info(f"Uploaded UTR file: {uploaded_file.name}")

                return file_public_url
            
            else:
                logger.debug("Could not locate source image. Returning")
        except NextcloudException as e:
            logger.warning(f"Failed to download image from {source_image_path}: {str(e)}")
            return None
            
    except Exception as e:
        logger.error(f"Error in upload_buyer_profile_image: {str(e)}")
        return ""

def insert_buyer_financial_info(cursor, financial_data, profile_id):
    """Insert data into buyer_financial_info table"""
    try:
        # Add profile_id to financial data
        financial_data["buyer_profile_id"] = profile_id
        
        # Set default values for missing fields
        financial_data["deposit_paid"] = True
        financial_data["entry_fee_paid"] = True
        financial_data["deposit_amount"] = 0
        financial_data["entry_fee_amount"] = 0
        
        # Prepare the SQL query
        columns = []
        values = []
        
        for key, value in financial_data.items():
            if value is not None and key in get_table_columns(cursor, "buyer_financial_info"):
                columns.append(key)
                values.append(value)
        
        placeholders = ", ".join(["%s"] * len(values))
        column_str = ", ".join(columns)
        
        query = f"INSERT INTO buyer_financial_info ({column_str}) VALUES ({placeholders}) RETURNING id"
        
        try:
            cursor.execute(query, values)
            financial_id = cursor.fetchone()[0]
        
            logger.info(f"Created buyer financial info with ID {financial_id} for profile {profile_id}")
        
            return financial_id
        except Exception as e:
            logger.error("SQL execution failed: %s | Params: %s | Error: %s", query, values, str(e))
            raise e
    except Exception as e:
        logger.error(f"Error inserting buyer financial info: {e}")
        return None

def insert_buyer_business_info(cursor, business_data, profile_id):
    """Insert data into buyer_business_info table"""
    try:
        # Add profile_id to business data
        business_data["buyer_profile_id"] = profile_id
        
        # Set default values for missing fields
        if "start_year" in business_data:
            try:
                if pd.isna(business_data["start_year"]) or not business_data["start_year"]:
                    business_data["start_year"] = 1900
                else:
                    business_data["start_year"] = int(float(business_data["start_year"]))
            except (ValueError, TypeError):
                logger.warning(f"Invalid start_year: {business_data['start_year']}, setting to 1900")
                business_data["start_year"] = 1900
        
        if "sell_wayanad_year" in business_data:
            try:
                if pd.isna(business_data["sell_wayanad_year"]) or not business_data["sell_wayanad_year"]:
                    business_data["sell_wayanad_year"] = 1900
                else:
                    business_data["sell_wayanad_year"] = int(float(business_data["sell_wayanad_year"]))
            except (ValueError, TypeError):
                logger.warning(f"Invalid sell_wayanad_year: {business_data['sell_wayanad_year']}, setting to 1900")
                business_data["sell_wayanad_year"] = 1900
        
        if "property_interest_1" in business_data and pd.isna(business_data["property_interest_1"]):
            business_data["property_interest_1"] = ""
        
        if "property_interest_2" in business_data and pd.isna(business_data["property_interest_2"]):
            business_data["property_interest_2"] = ""
        
        if "previous_stay_property" in business_data and pd.isna(business_data["previous_stay_property"]):
            business_data["previous_stay_property"] = ""
        
        # Prepare the SQL query
        columns = []
        values = []
        
        for key, value in business_data.items():
            if value is not None and key in get_table_columns(cursor, "buyer_business_info"):
                columns.append(key)
                values.append(value)
        
        placeholders = ", ".join(["%s"] * len(values))
        column_str = ", ".join(columns)
        
        query = f"INSERT INTO buyer_business_info ({column_str}) VALUES ({placeholders}) RETURNING id"
        
        try: 
            cursor.execute(query, values)
            business_id = cursor.fetchone()[0]
        
            logger.info(f"Created buyer business info with ID {business_id} for profile {profile_id}")
        
            return business_id
        except Exception as e:
            logger.error("SQL execution failed: %s | Params: %s | Error: %s", query, values, str(e))
            raise e
    except Exception as e:
        logger.error(f"Error inserting buyer business info: {e}")
        return None

def export_credentials(credentials_data):
    """Export user credentials to Excel file"""
    try:
        # Create a new workbook
        wb = Workbook()
        ws = wb.active
        if ws:
            ws.title = "Buyer Credentials"
            
            # Add headers
            #headers = ["User ID", "First Name", "Last Name", "Email", "Mobile", "Username", "Password"]
            headers = ["name", "email", "company", "user_id", "password"]
            for col_num, header in enumerate(headers, 1):
                try:
                    ws.cell(row=1, column=col_num).value = header
                    ws.cell(row=1, column=col_num).font = Font(bold=True)
                    ws.cell(row=1, column=col_num).fill = PatternFill(start_color="DDDDDD", end_color="DDDDDD", fill_type="solid")
                except AttributeError:
                    # Handle potential MergedCell issues
                    logger.warning(f"Could not format header cell at column {col_num}")
            
            # Add data
            for row_num, user in enumerate(credentials_data, 2):
                try:
                    # Set values directly
                    """
                    ws.cell(row=row_num, column=1).value = user["user_id"]
                    ws.cell(row=row_num, column=2).value = user["first_name"]
                    ws.cell(row=row_num, column=3).value = user["last_name"]
                    ws.cell(row=row_num, column=4).value = user["email"]
                    ws.cell(row=row_num, column=5).value = user["mobile"]
                    ws.cell(row=row_num, column=6).value = user["username"]
                    ws.cell(row=row_num, column=7).value = user["password"]
                    """
                    ws.cell(row=row_num, column=1).value = user["first_name"] + " "+ user["last_name"]
                    ws.cell(row=row_num, column=2).value = user["email"]
                    ws.cell(row=row_num, column=3).value = user["company"]
                    ws.cell(row=row_num, column=4).value = user["username"]
                    ws.cell(row=row_num, column=5).value = user["password"]

                except AttributeError:
                    # Handle potential MergedCell issues
                    logger.warning(f"Could not set values for row {row_num}")
        
        # Save the workbook
        output_path = os.path.join(SCRIPT_DIR, CREDENTIALS_FILE)
        wb.save(output_path)
        
        logger.info(f"Exported {len(credentials_data)} user credentials to {CREDENTIALS_FILE}")
        return True
    except Exception as e:
        logger.error(f"Error exporting credentials: {e}")
        return False

def main():
    """Main function to orchestrate the data import process"""
    # Parse command line arguments
    global DB_USER, DB_PASSWORD, DB_HOST, DB_PORT, DB_NAME, EXCEL_FILE, CREDENTIALS_FILE
    args = parse_arguments()
    
    # Set configuration variables from arguments
    DB_USER = args.db_user
    DB_PASSWORD = args.db_password
    DB_HOST = args.db_host
    DB_PORT = args.db_port
    DB_NAME = args.db_name
    EXCEL_FILE = args.input_file
    CREDENTIALS_FILE = args.output_file
    
    logger.info("Starting buyer data import process")
    logger.info(f"Using Excel file: {EXCEL_FILE}")
    logger.info(f"Using database: {DB_NAME} on {DB_HOST}:{DB_PORT}")
    logger.info(f"Output credentials will be saved to: {CREDENTIALS_FILE}")
    
    # Check if setup script has been executed
    check_setup_script_executed()
    
    # Read Excel data
    excel_data = read_excel_data(EXCEL_FILE)
    
    # Connect to the database
    try:
        conn = psycopg2.connect(
            user=DB_USER,
            password=DB_PASSWORD,
            host=DB_HOST,
            port=DB_PORT,
            database=DB_NAME
        )
        conn.autocommit = False  # Use transactions
        cursor = conn.cursor()
        logger.info(f"Connected to database {DB_NAME}")
        
        # Store credentials for export
        credentials = []
        
        # Process each row in the Excel file
        for index, row in excel_data.iterrows():
            try:
                # Set default values for blank fields
                if "Website" in row and pd.isna(row["Website"]):
                    row["Website"] = ""
                if "Instagram" in row and pd.isna(row["Instagram"]):
                    row["Instagram"] = ""
                if "GSTIN" in row and pd.isna(row["GSTIN"]):
                    row["GSTIN"] = ""
                if "Promoting Since" in row and pd.isna(row["Promoting Since"]):
                    row["Promoting Since"] = 1900
                if "Promoting Property 1" in row and pd.isna(row["Promoting Property 1"]):
                    row["Promoting Property 1"] = ""
                if "Promoting Property Address 1" in row and pd.isna(row["Promoting Property Address 1"]):
                    row["Promoting Property Address 1"] = ""
                if "Promoting Property 2" in row and pd.isna(row["Promoting Property 2"]):
                    row["Promoting Property 2"] = ""
                if "Promoting Property Address 2" in row and pd.isna(row["Promoting Property Address 2"]):
                    row["Promoting Property Address 2"] = ""
                if "Previous stayed property" in row and pd.isna(row["Previous stayed property"]):
                    row["Previous stayed property"] = ""
                
                # Start a transaction
                cursor.execute("BEGIN")
                
                # Prepare user data
                user_data = {
                    "username": row[COLUMN_MAPPINGS["users"]["username"]],
                    "email": row[COLUMN_MAPPINGS["users"]["email"]],
                    "business_name": row[COLUMN_MAPPINGS["users"]["business_name"]]
                }
                
                # Insert user and get user_id and password
                user_id, password = insert_user_data(cursor, user_data)
                
                if user_id:
                    # Parse name for credentials
                    first_name, last_name = parse_name(row["Name"])
                    
                    # Store credentials
                    credentials.append({
                        "user_id": user_id,
                        "username": user_data["username"],
                        "first_name": first_name,
                        "last_name": last_name,
                        "email": user_data["email"],
                        "mobile": row["Mobile"] if "Mobile" in row else "",
                        "company": row["Company"] if "Company" in row else "",
                        "password": password
                    })
                    
                    # Prepare buyer profile data
                    profile_data = {}
                    for db_col, excel_col in COLUMN_MAPPINGS["buyer_profiles"].items():
                        if excel_col and excel_col in row:
                            profile_data[db_col] = row[excel_col]
                    
                    # Insert buyer profile and get profile_id
                    profile_id = insert_buyer_profile_data(cursor, profile_data, user_id)
                    
                    if profile_id:
                        # Prepare references data
                        reference_data = {}
                        for db_col, excel_col in COLUMN_MAPPINGS["buyer_references"].items():
                            if excel_col and excel_col in row:
                                reference_data[db_col] = row[excel_col]
                        
                        # Insert references
                        insert_buyer_references(cursor, reference_data, profile_id)
                        
                        # Prepare misc data
                        misc_data = {}
                        for db_col, excel_col in COLUMN_MAPPINGS["buyer_misc"].items():
                            if excel_col and excel_col in row:
                                misc_data[db_col] = row[excel_col]
                        
                        # Insert misc data
                        insert_buyer_misc(cursor, misc_data, profile_id)
                        
                        # Prepare financial info data
                        financial_data = {}
                        for db_col, excel_col in COLUMN_MAPPINGS["buyer_financial_info"].items():
                            if excel_col and excel_col in row:
                                financial_data[db_col] = row[excel_col]
                        
                        # Insert financial info
                        insert_buyer_financial_info(cursor, financial_data, profile_id)
                        
                        # Prepare business info data
                        business_data = {}
                        for db_col, excel_col in COLUMN_MAPPINGS["buyer_business_info"].items():
                            if excel_col and excel_col in row:
                                business_data[db_col] = row[excel_col]
                        
                        # Insert business info
                        #insert_buyer_business_info(cursor, business_data, profile_id)
                        
                        # Check if UniqueId column exists in the row
                        #if 'UniqueID' in row and not pd.isna(row['UniqueID']):
                        #    unique_id = str(row['UniqueID']).strip()
                        #    if unique_id:
                        #        # Try to upload profile image
                        #        profile_image_url = upload_buyer_profile_image(unique_id, profile_id, cursor)
                        #        if profile_image_url:
                        #            logger.info(f"Updated profile image for buyer profile {profile_id}")
                        #        else:
                        #            logger.warning(f"Failed to update profile image for buyer profile {profile_id}")
                
                # Commit the transaction immediately after processing each row
                conn.commit()
                logger.info(f"Successfully imported buyer: {row['Name']} ({row['Email']})")
                
            except Exception as e:
                # Rollback in case of error
                conn.rollback()
                logger.error(f"Error importing buyer {row['Name']} ({row['Email']}): {e}")
        
        # Export credentials to Excel
        export_credentials(credentials)
        
        logger.info(f"Buyer data import completed. Imported {len(credentials)} buyers.")
        
    except Exception as e:
        logger.error(f"Database error: {e}")
    finally:
        # Close database connection
        if conn:
            cursor.close()
            conn.close()
            logger.info("Database connection closed")

if __name__ == "__main__":
    main()
