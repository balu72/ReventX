#!/usr/bin/env python3
"""
Seller Data Import Script for Splash25 Migration

This script:
1. Reads seller data from Excel file
2. Creates user accounts with secure passwords
3. Populates seller-related tables in the database
4. Exports user credentials to a separate Excel file
"""

import os
import sys
import logging
import random
import string
import subprocess
import argparse
import pandas as pd
import bcrypt
from datetime import datetime
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill

# Check for required libraries
try:
    import psycopg2
    from psycopg2 import sql
except ImportError:
    print("Error: Required Python libraries not found.")
    print("Please install required packages using: pip install -r requirements.txt")
    sys.exit(1)

# Default configuration variables
DEFAULT_DB_USER = "splash25user"
DEFAULT_DB_PASSWORD = "splash25password"
DEFAULT_DB_HOST = "localhost"
DEFAULT_DB_PORT = "5432"
DEFAULT_DB_NAME = "splash25_migration_test_db"
DEFAULT_EXCEL_FILE = "Sellers_20250622_With_Generated_Data.xlsx"
# Generate credentials filename with current date and time
DEFAULT_CREDENTIALS_FILE = f"seller_credentials_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"

# These will be set by parse_arguments() or use defaults
DB_USER = DEFAULT_DB_USER
DB_PASSWORD = DEFAULT_DB_PASSWORD
DB_HOST = DEFAULT_DB_HOST
DB_PORT = DEFAULT_DB_PORT
DB_NAME = DEFAULT_DB_NAME
EXCEL_FILE = DEFAULT_EXCEL_FILE
CREDENTIALS_FILE = DEFAULT_CREDENTIALS_FILE

# Set up logging
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
# Generate log filename with current date and time
LOG_FILE = os.path.join(SCRIPT_DIR, f"seller_import_log_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log")
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(LOG_FILE),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Column mappings section
COLUMN_MAPPINGS = {
    "users": {
        "username": "Generated User name",  # Use Generated User name as username
        "email": "Email",
        "password_hash": None,  # Will be generated
        "role": None,  # Will be set to 'seller'
        "business_name": "Company",
        "business_description": None  # Not available in Excel
    },
    "seller_profiles": {
        "user_id": None,  # Will be set from the created user
        "business_name": "Company",
        "company_name": "Company",
        "description": None,  # Not available in Excel
        "seller_type": "Seller Type",
        "target_market": "Target Market",
        "logo_url": None,  # Not available in Excel
        "website": "Website",
        "contact_email": "Email",
        "contact_phone": "Mobile",
        "mobile": "Mobile",
        "address": "Address",
        "is_verified": None,  # Will be set to False
        "pincode": "Pincode",
        "instagram": "Instagram",
        "status": None,  # Will be set to 'active'
        "assn_member": "WTO Member",  # Will be set based on 'WTO Member'
        "property_type_id": None,  # Will be set based on 'Seller Type'
        "state": "State",
        "city": "City",
        "country": None,  # Will be set to 'India'
        "business_images": None,  # Will be set to '[]'
        "salutation": None,  # Will be parsed from Name
        "first_name": None,  # Will be parsed from Name
        "last_name": None,  # Will be parsed from Name
        "designation": "Designation"
    },
    "seller_attendees": {
        "seller_profile_id": None,  # Will be set from the created profile
        "attendee_number": None,  # Will be set to 1
        "name": "Name",
        "designation": "Designation",
        "email": "Email",
        "mobile": "Mobile",
        "is_primary_contact": None  # Will be set to True
    },
    "seller_business_info": {
        "seller_profile_id": None,  # Will be set from the created profile
        "start_year": "Started On",
        "number_of_rooms": "Room Nos",
        "previous_business": "Got Business",  # Map to Got Business
        "previous_business_year": "Got Business Since"
    },
    "seller_financial_info": {
        "seller_profile_id": None,  # Will be set from the created profile
        "deposit_paid": None,  # Will be set to False
        "total_amt_due": None,  # Will be set to 0
        "total_amt_paid": None,  # Will be set to 0
        "subscription_uptodate": "Subs Upto Date",  # Map to Subs Upto Date
        "actual_additional_seller_passes": None  # Will be set to 0
    },
    "stalls": {
        "seller_id": None,  # Will be set from the created user
        "number": None,  # Will be set to 1
        "stall_type_id": None,  # Will be set based on 'Mapped Stall Type'
        "fascia_name": "Fascia",
        "is_allocated": None  # Will be set to False
    }
}

def parse_arguments():
    """Parse command line arguments"""
    parser = argparse.ArgumentParser(description="Import seller data from Excel to database")
    
    # Add arguments
    parser.add_argument("-i", "--input-file", 
                        help=f"Input Excel file path (default: {DEFAULT_EXCEL_FILE})",
                        default=DEFAULT_EXCEL_FILE)
    
    parser.add_argument("-d", "--db-name", 
                        help=f"Database name (default: {DEFAULT_DB_NAME})",
                        default=DEFAULT_DB_NAME)
    
    parser.add_argument("-H", "--db-host", 
                        help=f"Database host (default: {DEFAULT_DB_HOST})",
                        default=DEFAULT_DB_HOST)
    
    parser.add_argument("-p", "--db-port", 
                        help=f"Database port (default: {DEFAULT_DB_PORT})",
                        default=DEFAULT_DB_PORT)
    
    parser.add_argument("-u", "--db-user", 
                        help=f"Database user (default: {DEFAULT_DB_USER})",
                        default=DEFAULT_DB_USER)
    
    parser.add_argument("-pw", "--db-password", 
                        help=f"Database password (default: {DEFAULT_DB_PASSWORD})",
                        default=DEFAULT_DB_PASSWORD)
    
    parser.add_argument("-o", "--output-file", 
                        help=f"Output credentials file (default: {DEFAULT_CREDENTIALS_FILE})",
                        default=DEFAULT_CREDENTIALS_FILE)
    
    return parser.parse_args()

def check_setup_script_executed():
    """Ask user to confirm setup script has been executed"""
    response = input("Have you already executed setup_migration_db.py? (Yes/No): ")
    if response.lower() != "yes":
        logger.info("Running setup_migration_db.py first...")
        try:
            setup_script = os.path.join(SCRIPT_DIR, "setup_migration_db.py")
            # Pass database connection parameters to setup script
            subprocess.run([
                "python3", 
                setup_script,
                "-d", DB_NAME,
                "-H", DB_HOST,
                "-p", DB_PORT,
                "-u", DB_USER,
                "-pw", DB_PASSWORD
            ], check=True)
            logger.info("Setup script completed successfully.")
        except subprocess.CalledProcessError as e:
            logger.error(f"Failed to run setup script: {e}")
            sys.exit(1)
    else:
        logger.info("Proceeding with seller data import...")

def generate_password():
    """Generate a secure random password between 8-10 characters"""
    # Define character sets
    lowercase = string.ascii_lowercase
    uppercase = string.ascii_uppercase
    digits = string.digits
    special = "!@#$%^&*()-_=+[]{}|;:,.<>?"
    
    # Randomly choose a length between 8 and 10
    length = random.randint(8, 10)
    
    # Ensure at least one character from each set
    password = [
        random.choice(lowercase),
        random.choice(uppercase),
        random.choice(digits),
        random.choice(special)
    ]
    
    # Fill the rest of the password
    remaining_length = length - len(password)
    all_chars = lowercase + uppercase + digits + special
    password.extend(random.choice(all_chars) for _ in range(remaining_length))
    
    # Shuffle the password characters
    random.shuffle(password)
    
    return ''.join(password)

def hash_password(password):
    """Create a bcrypt hash of the password using BF salt"""
    # Generate a salt and hash the password
    salt = bcrypt.gensalt()  # Uses BF by default
    hashed = bcrypt.hashpw(password.encode('utf-8'), salt)
    return hashed.decode('utf-8')

def parse_name(full_name):
    """Parse full name into salutation, first name, middle name, and last name"""
    if not full_name or pd.isna(full_name):
        return None, "", "", ""
    
    # Common salutations
    salutations = ["Mr.", "Mrs.", "Ms.", "Dr.", "Prof.", "Sir", "Madam"]
    
    # Split the name by spaces
    name_parts = full_name.strip().split()
    
    if len(name_parts) == 0:
        return None, "", "", ""
    
    # Check if the first part is a salutation
    salutation = None
    start_index = 0
    
    for sal in salutations:
        if name_parts[0].lower() == sal.lower() or name_parts[0].lower() == sal.lower().rstrip('.'):
            salutation = sal
            start_index = 1
            break
    
    # Extract first, middle, and last names
    if len(name_parts) <= start_index:
        return salutation, "", "", ""
    
    first_name = name_parts[start_index]
    
    if len(name_parts) <= start_index + 1:
        return salutation, first_name, "", ""
    
    if len(name_parts) <= start_index + 2:
        last_name = name_parts[start_index + 1]
        middle_name = ""
    else:
        # If more than 3 parts (including salutation), treat everything between first and last as middle
        middle_name = " ".join(name_parts[start_index + 1:-1])
        last_name = name_parts[-1]
    
    return salutation, first_name, middle_name, last_name

def check_username_exists(cursor, username):
    """Check if a username already exists in the database"""
    try:
        cursor.execute("SELECT id FROM users WHERE username = %s", (username,))
        return cursor.fetchone() is not None
    except Exception as e:
        logger.error(f"Error checking username existence: {e}")
        return False

def generate_unique_username(cursor, base_username):
    """Generate a unique username by appending numbers if necessary"""
    if not base_username or pd.isna(base_username):
        base_username = "user"  # Default username if none provided
    
    username = base_username
    counter = 1
    
    # Keep checking and appending numbers until a unique username is found
    while check_username_exists(cursor, username):
        username = f"{base_username}{counter}"
        counter += 1
    
    return username

def check_property_type_exists(cursor, property_type):
    """Check if a property type exists in the property_types table"""
    if not property_type or pd.isna(property_type):
        return None
    
    try:
        cursor.execute("SELECT id FROM property_types WHERE name = %s", (property_type,))
        result = cursor.fetchone()
        return result[0] if result else None
    except Exception as e:
        logger.error(f"Error checking property type existence: {e}")
        return None

def read_excel_data(file_path):
    """Read data from Excel file"""
    try:
        excel_path = os.path.join(SCRIPT_DIR, file_path)
        df = pd.read_excel(excel_path)
        logger.info(f"Successfully read {len(df)} records from {file_path}")
        return df
    except Exception as e:
        logger.error(f"Error reading Excel file: {e}")
        sys.exit(1)

def get_table_columns(cursor, table_name):
    """Get column names for a database table"""
    try:
        cursor.execute(f"SELECT column_name FROM information_schema.columns WHERE table_name = '{table_name}' ORDER BY ordinal_position")
        columns = [row[0] for row in cursor.fetchall()]
        return columns
    except Exception as e:
        logger.error(f"Error getting columns for table {table_name}: {e}")
        return []

def insert_user_data(cursor, user_data):
    """Insert data into users table"""
    try:
        # Generate a password and hash it
        clear_password = generate_password()
        password_hash = hash_password(clear_password)
        
        # Check if username exists and generate a unique one if needed
        username = generate_unique_username(cursor, user_data.get("username"))
        
        # Prepare the SQL query
        columns = ["username", "email", "password_hash", "role", "business_name"]
        values = [
            username,
            user_data.get("email"),
            password_hash,
            "seller",
            user_data.get("business_name")
        ]
        
        placeholders = ", ".join(["%s"] * len(values))
        column_str = ", ".join(columns)
        
        query = f"INSERT INTO users ({column_str}) VALUES ({placeholders}) RETURNING id"
        
        cursor.execute(query, values)
        user_id = cursor.fetchone()[0]
        
        logger.info(f"Created user with ID {user_id} for {user_data.get('email')} with username {username}")
        
        # Return user ID, clear text password, and the actual username used
        return user_id, clear_password, username
    except Exception as e:
        logger.error(f"Error inserting user data: {e}")
        return None, None, None

def insert_seller_profile_data(cursor, profile_data, user_id):
    """Insert data into seller_profiles table"""
    try:
        # Add user_id to profile data
        profile_data["user_id"] = user_id
        
        # Set default values for missing fields
        profile_data["is_verified"] = False
        profile_data["status"] = "active"
        profile_data["country"] = "India"
        profile_data["business_images"] = "[]"
        
        # Convert assn_member to boolean
        if "assn_member" in profile_data:
            profile_data["assn_member"] = str(profile_data["assn_member"]).lower() in ["yes", "y", "true", "1"]
        else:
            profile_data["assn_member"] = False
        
        # Check target_market length
        if "target_market" in profile_data and profile_data["target_market"] is not None:
            if len(str(profile_data["target_market"])) > 200:
                logger.warning(f"Target market for user {user_id} exceeds 200 characters, truncating")
                profile_data["target_market"] = ""
        
        # Check property_type_id
        if "seller_type" in profile_data and profile_data["seller_type"] is not None:
            property_type_id = check_property_type_exists(cursor, profile_data["seller_type"])
            if property_type_id:
                profile_data["property_type_id"] = property_type_id
            else:
                logger.warning(f"Property type '{profile_data['seller_type']}' not found, leaving blank")
                profile_data["seller_type"] = ""
        
        # Prepare the SQL query
        columns = []
        values = []
        
        for key, value in profile_data.items():
            if value is not None and key in get_table_columns(cursor, "seller_profiles"):
                columns.append(key)
                values.append(value)
        
        placeholders = ", ".join(["%s"] * len(values))
        column_str = ", ".join(columns)
        
        query = f"INSERT INTO seller_profiles ({column_str}) VALUES ({placeholders}) RETURNING id"
        
        cursor.execute(query, values)
        profile_id = cursor.fetchone()[0]
        
        logger.info(f"Created seller profile with ID {profile_id} for user {user_id}")
        
        return profile_id
    except Exception as e:
        logger.error(f"Error inserting seller profile data: {e}")
        return None

def insert_seller_attendee(cursor, profile_id, attendee_data):
    """Insert data into seller_attendees table"""
    try:
        # Add profile_id to attendee data
        attendee_data["seller_profile_id"] = profile_id
        
        # Set default values
        attendee_data["attendee_number"] = 1
        attendee_data["is_primary_contact"] = True
        
        # Prepare the SQL query
        columns = []
        values = []
        
        for key, value in attendee_data.items():
            if value is not None and key in get_table_columns(cursor, "seller_attendees"):
                columns.append(key)
                values.append(value)
        
        placeholders = ", ".join(["%s"] * len(values))
        column_str = ", ".join(columns)
        
        query = f"INSERT INTO seller_attendees ({column_str}) VALUES ({placeholders}) RETURNING id"
        
        cursor.execute(query, values)
        attendee_id = cursor.fetchone()[0]
        
        logger.info(f"Created seller attendee with ID {attendee_id} for profile {profile_id}")
        
        return attendee_id
    except Exception as e:
        logger.error(f"Error inserting seller attendee: {e}")
        return None

def insert_seller_financial_info(cursor, financial_data, profile_id):
    """Insert data into seller_financial_info table"""
    try:
        # Add profile_id to financial data
        financial_data["seller_profile_id"] = profile_id
        
        # Set default values for missing fields
        financial_data["deposit_paid"] = False
        financial_data["total_amt_due"] = 0
        financial_data["total_amt_paid"] = 0
        financial_data["actual_additional_seller_passes"] = 0
        
        # Convert subscription_uptodate to boolean
        if "subscription_uptodate" in financial_data:
            financial_data["subscription_uptodate"] = str(financial_data["subscription_uptodate"]).lower() in ["yes", "y", "true", "1"]
        else:
            financial_data["subscription_uptodate"] = False
        
        # Prepare the SQL query
        columns = []
        values = []
        
        for key, value in financial_data.items():
            if value is not None and key in get_table_columns(cursor, "seller_financial_info"):
                columns.append(key)
                values.append(value)
        
        placeholders = ", ".join(["%s"] * len(values))
        column_str = ", ".join(columns)
        
        query = f"INSERT INTO seller_financial_info ({column_str}) VALUES ({placeholders}) RETURNING id"
        
        cursor.execute(query, values)
        financial_id = cursor.fetchone()[0]
        
        logger.info(f"Created seller financial info with ID {financial_id} for profile {profile_id}")
        
        return financial_id
    except Exception as e:
        logger.error(f"Error inserting seller financial info: {e}")
        return None

def insert_seller_business_info(cursor, business_data, profile_id):
    """Insert data into seller_business_info table"""
    try:
        # Add profile_id to business data
        business_data["seller_profile_id"] = profile_id
        
        # Convert previous_business to boolean
        if "previous_business" in business_data:
            business_data["previous_business"] = str(business_data["previous_business"]).lower() in ["yes", "y", "true", "1"]
        else:
            business_data["previous_business"] = False
        
        # Prepare the SQL query
        columns = []
        values = []
        
        for key, value in business_data.items():
            if value is not None and key in get_table_columns(cursor, "seller_business_info"):
                columns.append(key)
                values.append(value)
        
        placeholders = ", ".join(["%s"] * len(values))
        column_str = ", ".join(columns)
        
        query = f"INSERT INTO seller_business_info ({column_str}) VALUES ({placeholders}) RETURNING id"
        
        cursor.execute(query, values)
        business_id = cursor.fetchone()[0]
        
        logger.info(f"Created seller business info with ID {business_id} for profile {profile_id}")
        
        return business_id
    except Exception as e:
        logger.error(f"Error inserting seller business info: {e}")
        return None

def insert_stall(cursor, user_id, stall_data):
    """Insert data into stalls table"""
    try:
        # Add user_id to stall data
        stall_data["seller_id"] = user_id
        
        # Set default values
        stall_data["number"] = "1"
        stall_data["is_allocated"] = False
        
        # Get stall_type_id based on Mapped Stall Type
        if "stall_type_name" in stall_data and stall_data["stall_type_name"] is not None:
            cursor.execute("SELECT id FROM stall_types WHERE name = %s", (stall_data["stall_type_name"],))
            result = cursor.fetchone()
            if result:
                stall_data["stall_type_id"] = result[0]
                # Remove the temporary stall_type_name field
                del stall_data["stall_type_name"]
            else:
                logger.warning(f"Stall type '{stall_data['stall_type_name']}' not found")
                # Remove the temporary stall_type_name field
                del stall_data["stall_type_name"]
        
        # Prepare the SQL query
        columns = []
        values = []
        
        for key, value in stall_data.items():
            if value is not None and key in get_table_columns(cursor, "stalls"):
                columns.append(key)
                values.append(value)
        
        placeholders = ", ".join(["%s"] * len(values))
        column_str = ", ".join(columns)
        
        query = f"INSERT INTO stalls ({column_str}) VALUES ({placeholders}) RETURNING id"
        
        cursor.execute(query, values)
        stall_id = cursor.fetchone()[0]
        
        logger.info(f"Created stall with ID {stall_id} for user {user_id}")
        
        return stall_id
    except Exception as e:
        logger.error(f"Error inserting stall: {e}")
        return None

def export_credentials(credentials_data):
    """Export user credentials to Excel file"""
    try:
        # Create a new workbook
        wb = Workbook()
        ws = wb.active
        if ws:
            ws.title = "Seller Credentials"
            
            # Add headers
            headers = ["name", "email", "company", "user_id", "password"]
            for col_num, header in enumerate(headers, 1):
                try:
                    ws.cell(row=1, column=col_num).value = header
                    ws.cell(row=1, column=col_num).font = Font(bold=True)
                    ws.cell(row=1, column=col_num).fill = PatternFill(start_color="DDDDDD", end_color="DDDDDD", fill_type="solid")
                except AttributeError:
                    # Handle potential MergedCell issues
                    logger.warning(f"Could not format header cell at column {col_num}")
            
            # Add data
            for row_num, user in enumerate(credentials_data, 2):
                try:
                    # Set values directly
                    ws.cell(row=row_num, column=1).value = user["first_name"] + " "+ user["last_name"]
                    ws.cell(row=row_num, column=2).value = user["email"]
                    ws.cell(row=row_num, column=3).value = user["company"]
                    ws.cell(row=row_num, column=4).value = user["username"]
                    ws.cell(row=row_num, column=5).value = user["password"]
                except AttributeError:
                    # Handle potential MergedCell issues
                    logger.warning(f"Could not set values for row {row_num}")
        
        # Save the workbook
        output_path = os.path.join(SCRIPT_DIR, CREDENTIALS_FILE)
        wb.save(output_path)
        
        logger.info(f"Exported {len(credentials_data)} user credentials to {CREDENTIALS_FILE}")
        return True
    except Exception as e:
        logger.error(f"Error exporting credentials: {e}")
        return False

def main():
    """Main function to orchestrate the data import process"""
    # Parse command line arguments
    global DB_USER, DB_PASSWORD, DB_HOST, DB_PORT, DB_NAME, EXCEL_FILE, CREDENTIALS_FILE
    args = parse_arguments()
    skip_column_name = "Sl.No"
    
    # Set configuration variables from arguments
    DB_USER = args.db_user
    DB_PASSWORD = args.db_password
    DB_HOST = args.db_host
    DB_PORT = args.db_port
    DB_NAME = args.db_name
    EXCEL_FILE = args.input_file
    CREDENTIALS_FILE = args.output_file
    
    logger.info("Starting seller data import process")
    logger.info(f"Using Excel file: {EXCEL_FILE}")
    logger.info(f"Using database: {DB_NAME} on {DB_HOST}:{DB_PORT}")
    logger.info(f"Output credentials will be saved to: {CREDENTIALS_FILE}")
    
    # Check if setup script has been executed
    check_setup_script_executed()
    
    # Read Excel data
    excel_data = read_excel_data(EXCEL_FILE)
    
    # Connect to the database
    try:
        conn = psycopg2.connect(
            user=DB_USER,
            password=DB_PASSWORD,
            host=DB_HOST,
            port=DB_PORT,
            database=DB_NAME
        )
        conn.autocommit = False  # Use transactions
        cursor = conn.cursor()
        logger.info(f"Connected to database {DB_NAME}")
        
        # Store credentials for export
        credentials = []
        
        # Process each row in the Excel file
        for index, row in excel_data.iterrows():
            try:
                # Skip rows where "Sl. No" is "N"
                if skip_column_name in row and str(row[skip_column_name]).strip().upper() == "N":
                    logger.info(f"Skipping row {index+1} with Sl.No = N")
                    continue
                
                # Start a transaction
                cursor.execute("BEGIN")
                
                # Prepare user data
                user_data = {
                    "username": row[COLUMN_MAPPINGS["users"]["username"]],
                    "email": row[COLUMN_MAPPINGS["users"]["email"]],
                    "business_name": row[COLUMN_MAPPINGS["users"]["business_name"]]
                }
                
                # Insert user and get user_id, password, and actual username
                user_id, password, username = insert_user_data(cursor, user_data)
                
                if user_id:
                    # Parse name for profile and credentials
                    salutation, first_name, middle_name, last_name = parse_name(row["Name"])
                    
                    # Prepare seller profile data
                    profile_data = {}
                    for db_col, excel_col in COLUMN_MAPPINGS["seller_profiles"].items():
                        if excel_col and excel_col in row:
                            profile_data[db_col] = row[excel_col]
                    
                    # Add parsed name components
                    profile_data["salutation"] = salutation
                    profile_data["first_name"] = first_name
                    profile_data["last_name"] = last_name
                    
                    # Insert seller profile and get profile_id
                    profile_id = insert_seller_profile_data(cursor, profile_data, user_id)
                    
                    if profile_id:
                        # Store credentials
                        credentials.append({
                            "first_name": first_name,
                            "last_name": last_name,
                            "email": user_data["email"],
                            "mobile": row["Mobile"] if "Mobile" in row else "",
                            "company": row["Company"] if "Company" in row else "",
                            "username": username,
                            "password": password
                        })
                        
                        # Prepare attendee data
                        attendee_data = {}
                        for db_col, excel_col in COLUMN_MAPPINGS["seller_attendees"].items():
                            if excel_col and excel_col in row:
                                attendee_data[db_col] = row[excel_col]
                        
                        # Insert attendee
                        insert_seller_attendee(cursor, profile_id, attendee_data)
                        
                        # Prepare financial info data
                        financial_data = {}
                        for db_col, excel_col in COLUMN_MAPPINGS["seller_financial_info"].items():
                            if excel_col and excel_col in row:
                                financial_data[db_col] = row[excel_col]
                        
                        # Insert financial info
                        insert_seller_financial_info(cursor, financial_data, profile_id)
                        
                        # Prepare business info data
                        business_data = {}
                        for db_col, excel_col in COLUMN_MAPPINGS["seller_business_info"].items():
                            if excel_col and excel_col in row:
                                business_data[db_col] = row[excel_col]
                        
                        # Insert business info
                        #insert_seller_business_info(cursor, business_data, profile_id)
                        
                        # Prepare stall data
                        stall_data = {}
                        for db_col, excel_col in COLUMN_MAPPINGS["stalls"].items():
                            if excel_col and excel_col in row:
                                stall_data[db_col] = row[excel_col]
                        
                        # Add stall type name for lookup
                        if "Mapped Stall Type" in row:
                            stall_data["stall_type_name"] = row["Mapped Stall Type"]
                        
                        # Insert stall
                        insert_stall(cursor, user_id, stall_data)
                
                # Commit the transaction immediately after processing each row
                conn.commit()
                logger.info(f"Successfully imported seller: {row['Name']} ({row['Email']})")
                
            except Exception as e:
                # Rollback in case of error
                conn.rollback()
                logger.error(f"Error importing seller {row['Name']} ({row['Email']}): {e}")
        
        # Export credentials to Excel
        export_credentials(credentials)
        
        logger.info(f"Seller data import completed. Imported {len(credentials)} sellers.")
        
    except Exception as e:
        logger.error(f"Database error: {e}")
    finally:
        # Close database connection
        if conn:
            cursor.close()
            conn.close()
            logger.info("Database connection closed")

if __name__ == "__main__":
    main()
