#!/usr/bin/env python3
"""
Database Setup Script for Splash25 Migration Test Database

This script:
1. Connects to PostgreSQL using provided or default credentials
2. Creates a new database (if it doesn't exist)
3. Executes schema creation and master data loading SQL scripts

Usage:
    python setup_migration_db.py [options]

Options:
    -d, --db-name        Database name (default: splash25_migration_test_db)
    -H, --db-host        Database host (default: localhost)
    -p, --db-port        Database port (default: 5432)
    -u, --db-user        Database user (default: splash25user)
    -pw, --db-password   Database password (default: splash25password)
    -s, --schema-path    Schema SQL file path (default: 01_create_splash25_schema.sql)
    -m, --master-path    Master data SQL file path (default: 02_load_splash25_master_data.sql)
"""

import os
import sys
import logging
import argparse
from datetime import datetime

# Check for required libraries
try:
    import psycopg2
    from psycopg2 import sql
    from psycopg2.extensions import ISOLATION_LEVEL_AUTOCOMMIT
except ImportError:
    print("Error: Required Python libraries not found.")
    print("Please install required packages using: pip install -r requirements.txt")
    sys.exit(1)

# Default configuration variables
DEFAULT_DB_USER = "splash25user"
DEFAULT_DB_PASSWORD = "splash25password"  # In production, this should be stored securely
DEFAULT_DB_HOST = "localhost"
DEFAULT_DB_PORT = "5432"
DEFAULT_DB_NAME = "splash25_migration_test_db"

# Get the directory where this script is located
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

# Default SQL script paths (relative to this script)
DEFAULT_SCHEMA_SQL_PATH = os.path.join(SCRIPT_DIR, "01_create_splash25_schema.sql")
DEFAULT_MASTER_DATA_SQL_PATH = os.path.join(SCRIPT_DIR, "02_load_splash25_master_data.sql")

# These will be set by parse_arguments() or use defaults
DB_USER = DEFAULT_DB_USER
DB_PASSWORD = DEFAULT_DB_PASSWORD
DB_HOST = DEFAULT_DB_HOST
DB_PORT = DEFAULT_DB_PORT
NEW_DB_NAME = DEFAULT_DB_NAME
SCHEMA_SQL_PATH = DEFAULT_SCHEMA_SQL_PATH
MASTER_DATA_SQL_PATH = DEFAULT_MASTER_DATA_SQL_PATH

# Set up logging with timestamped filename
LOG_FILE = os.path.join(SCRIPT_DIR, f"splash25_schema_master_data_setup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log")
logging.basicConfig(
    level=logging.DEBUG,  # Set to DEBUG level for more detailed logging
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(LOG_FILE),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

def parse_arguments():
    """Parse command line arguments"""
    parser = argparse.ArgumentParser(description="Setup Splash25 migration test database")
    
    # Add arguments
    parser.add_argument("-d", "--db-name", 
                        help=f"Database name (default: {DEFAULT_DB_NAME})",
                        default=DEFAULT_DB_NAME)
    
    parser.add_argument("-H", "--db-host", 
                        help=f"Database host (default: {DEFAULT_DB_HOST})",
                        default=DEFAULT_DB_HOST)
    
    parser.add_argument("-p", "--db-port", 
                        help=f"Database port (default: {DEFAULT_DB_PORT})",
                        default=DEFAULT_DB_PORT)
    
    parser.add_argument("-u", "--db-user", 
                        help=f"Database user (default: {DEFAULT_DB_USER})",
                        default=DEFAULT_DB_USER)
    
    parser.add_argument("-pw", "--db-password", 
                        help=f"Database password (default: {DEFAULT_DB_PASSWORD})",
                        default=DEFAULT_DB_PASSWORD)
    
    parser.add_argument("-s", "--schema-path", 
                        help=f"Schema SQL file path (default: {os.path.basename(DEFAULT_SCHEMA_SQL_PATH)})",
                        default=DEFAULT_SCHEMA_SQL_PATH)
    
    parser.add_argument("-m", "--master-path", 
                        help=f"Master data SQL file path (default: {os.path.basename(DEFAULT_MASTER_DATA_SQL_PATH)})",
                        default=DEFAULT_MASTER_DATA_SQL_PATH)
    
    return parser.parse_args()

def check_db_connection():
    """Check if the PostgreSQL server is running and accessible"""
    try:
        conn = psycopg2.connect(
            user=DB_USER,
            password=DB_PASSWORD,
            host=DB_HOST,
            port=DB_PORT,
            database="postgres",
            connect_timeout=5
        )
        conn.close()
        return True
    except Exception as e:
        logger.error(f"Cannot connect to PostgreSQL server: {e}")
        return False

def database_exists(cursor, db_name):
    """Check if a database already exists"""
    cursor.execute("SELECT 1 FROM pg_database WHERE datname = %s", (db_name,))
    return cursor.fetchone() is not None

def main():
    # Parse command line arguments
    global DB_USER, DB_PASSWORD, DB_HOST, DB_PORT, NEW_DB_NAME, SCHEMA_SQL_PATH, MASTER_DATA_SQL_PATH
    args = parse_arguments()
    
    # Set configuration variables from arguments
    DB_USER = args.db_user
    DB_PASSWORD = args.db_password
    DB_HOST = args.db_host
    DB_PORT = args.db_port
    NEW_DB_NAME = args.db_name
    SCHEMA_SQL_PATH = args.schema_path
    MASTER_DATA_SQL_PATH = args.master_path
    
    logger.info("Starting database migration process")
    logger.debug(f"Using database: {NEW_DB_NAME} on {DB_HOST}:{DB_PORT}")
    logger.debug(f"Using schema SQL file: {SCHEMA_SQL_PATH}")
    logger.debug(f"Using master data SQL file: {MASTER_DATA_SQL_PATH}")
    
    # Check if SQL files exist
    if not os.path.exists(SCHEMA_SQL_PATH):
        logger.error(f"Schema SQL file not found: {SCHEMA_SQL_PATH}")
        sys.exit(1)
    if not os.path.exists(MASTER_DATA_SQL_PATH):
        logger.error(f"Master data SQL file not found: {MASTER_DATA_SQL_PATH}")
        sys.exit(1)
    
    # Step 1: Check if PostgreSQL server is running
    logger.info("Checking PostgreSQL server connection...")
    if not check_db_connection():
        logger.error("PostgreSQL server is not accessible. Please check if it's running.")
        sys.exit(1)
    
    # Step 2: Connect to PostgreSQL server (using postgres database initially)
    try:
        # Connect to default database to create new database
        conn = psycopg2.connect(
            user=DB_USER,
            password=DB_PASSWORD,
            host=DB_HOST,
            port=DB_PORT,
            database="postgres"
        )
        conn.set_isolation_level(ISOLATION_LEVEL_AUTOCOMMIT)
        cursor = conn.cursor()
        logger.info(f"Connected to PostgreSQL server as {DB_USER}")
        
        # Step 3: Check if database already exists
        goto_execute_scripts = False
        if database_exists(cursor, NEW_DB_NAME):
            logger.warning(f"Database {NEW_DB_NAME} already exists")
            user_input = input(f"Database {NEW_DB_NAME} already exists. Do you want to drop and recreate it? (y/n): ")
            if user_input.lower() == 'y':
                logger.info(f"Dropping existing database: {NEW_DB_NAME}")
                cursor.execute(sql.SQL("DROP DATABASE {}").format(sql.Identifier(NEW_DB_NAME)))
                logger.info(f"Database {NEW_DB_NAME} dropped")
            else:
                logger.info("Using existing database")
                # Close initial connection
                cursor.close()
                conn.close()
                
                # Connect to the existing database
                conn = psycopg2.connect(
                    user=DB_USER,
                    password=DB_PASSWORD,
                    host=DB_HOST,
                    port=DB_PORT,
                    database=NEW_DB_NAME
                )
                cursor = conn.cursor()
                logger.info(f"Connected to existing {NEW_DB_NAME} database")
                
                # Skip to step 5
                goto_execute_scripts = True
        
        # Step 4: Create new database (if it doesn't exist or user chose to recreate)
        if not goto_execute_scripts:
            logger.info(f"Creating database: {NEW_DB_NAME}")
            cursor.execute(sql.SQL("CREATE DATABASE {}").format(sql.Identifier(NEW_DB_NAME)))
            logger.info(f"Database {NEW_DB_NAME} created successfully")
            
            # Close initial connection
            cursor.close()
            conn.close()
            
            # Connect to the new database
            conn = psycopg2.connect(
                user=DB_USER,
                password=DB_PASSWORD,
                host=DB_HOST,
                port=DB_PORT,
                database=NEW_DB_NAME
            )
            cursor = conn.cursor()
            logger.info(f"Connected to {NEW_DB_NAME} database")
        
        # Step 5: Execute schema creation script
        logger.info(f"Executing schema creation script: {SCHEMA_SQL_PATH}")
        with open(SCHEMA_SQL_PATH, 'r') as schema_file:
            schema_sql = schema_file.read()
            logger.debug(f"Schema SQL script size: {len(schema_sql)} bytes")
            cursor.execute(schema_sql)
        conn.commit()
        logger.info("Schema created successfully")
        
        # Step 6: Execute master data loading script
        logger.info(f"Executing master data loading script: {MASTER_DATA_SQL_PATH}")
        with open(MASTER_DATA_SQL_PATH, 'r') as data_file:
            data_sql = data_file.read()
            logger.debug(f"Master data SQL script size: {len(data_sql)} bytes")
            cursor.execute(data_sql)
        conn.commit()
        logger.info("Master data loaded successfully")
        
        # Step 7: Verify setup by counting tables
        cursor.execute("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = 'public'")
        table_count = cursor.fetchone()[0]
        logger.info(f"Database setup complete. {table_count} tables created.")
        
        # Additional verification at DEBUG level
        logger.debug("Listing created tables:")
        cursor.execute("SELECT table_name FROM information_schema.tables WHERE table_schema = 'public' ORDER BY table_name")
        tables = cursor.fetchall()
        if tables:
            for table in tables:
                logger.debug(f"  - {table[0]}")
        else:
            logger.debug("No tables found in the database.")
        
    except Exception as e:
        logger.error(f"Error: {e}")
        sys.exit(1)
    finally:
        # Close connection
        if 'conn' in locals() and conn:
            cursor.close()
            conn.close()
            logger.info("Database connection closed")

if __name__ == "__main__":
    main()
